<?php include 'header.php'; ?>

    <!-- Being Page Title -->
    <div class="container">
        <div class="page-title clearfix">
            <div class="row">
                <div class="col-md-12">
                    <h6><a href="Pre_index-2.html">Preschool</a></h6>
                    <h6><a href="#">Admission</a></h6>
                    <h6><span class="page-active">Fees</span></h6>
                </div>
            </div>
        </div>
    </div>


    <div class="container">
        <div class="row">

            <!-- Here begin Main Content -->
           <div class="col-md-8">

                <div class="row">
                    <div class="col-md-12">
                        
                        <div class="course-post">
                            <div class="course-image">
                                <img src="images/course/Fee.jpg" alt="">
                            </div> <!-- /.course-image -->
                             <div class="course-details clearfix">
                                <h3 class="course-post-title">Fees</h3>
                                <p><i>Please contact the Accounts Office for details of our fees using the following contact information:</i></p>
                                <p><h4>Accounts Office:</h4></p>
                                <p><Strong>Email: </Strong><a href="mailto:accounts@desvyisl.com">accounts@desvyisl.com</a></p>
                                <p><strong>Telephone:</strong>(055) 741-3250</p>
                                <p>Thank you!</p>


                            </div> <!-- /.course-details -->
                        </div> <!-- /.course-post -->

                    </div> <!-- /.col-md-12 -->
                </div> <!-- /.row -->

            </div> <!-- /.col-md-8 -->


            <!-- Here begin Sidebar -->
            <div class="col-md-4">

               <div class="widget-main">
                            <div class="widget-main-title">
                                <h4 class="widget-title">Upcoming Events</h4>
                            </div> <!-- /.widget-main-title -->
                            <div class="widget-inner">
                                <div class="event-small-list clearfix">
                                    <div class="calendar-small">
                                        <span class="s-month">Jan</span>
                                        <span class="s-date">12</span>
                                    </div>
                                    <div class="event-small-details">
                                        <h5 class="event-small-title"><a href="#">Opening Day at Desvy International School</a></h5>
                                        <p class="event-small-meta small-text">Santeo East Legon Hills 9:00 AM to 1:00 PM</p>
                                    </div>
                                </div>
                                <div class="event-small-list clearfix">
                                    <div class="calendar-small">
                                        <span class="s-month">Jan</span>
                                        <span class="s-date">09</span>
                                    </div>
                                    <div class="event-small-details">
                                        <h5 class="event-small-title"><a href="#">Career Day at Desvy International School </a></h5>
                                        <p class="event-small-meta small-text">Santeo East Legon Hills 4:30 PM to 6:00 PM</p>
                                    </div>
                                </div>
                                <div class="event-small-list clearfix">
                                    <div class="calendar-small">
                                        <span class="s-month">Jan</span>
                                        <span class="s-date">02</span>
                                    </div>
                                    <div class="event-small-details">
                                        <h5 class="event-small-title"><a href="#">Desvy International School FanFare</a></h5>
                                        <p class="event-small-meta small-text">Santeo East Legon Hills 12:00 PM to 1:00 PM</p>
                                    </div>
                                </div>
                            </div> <!-- /.widget-inner -->
                        </div> <!-- /.widget-main -->
             
                
          

                <div class="widget-main">
                    <div class="widget-main-title">
                        <h4 class="widget-title">Our Gallery</h4>
                    </div>
                    <div class="widget-inner">
                        <div class="gallery-small-thumbs clearfix">
                            <div class="thumb-small-gallery">
                                <a class="fancybox" rel="gallery1" href="images/gallery/2.jpeg" title="Gallery Tittle One">
                                    <img src="images/gallery/2thumbnail.png" alt="" />
                                </a>
                            </div>
                            <div class="thumb-small-gallery">
                                <a class="fancybox" rel="gallery1" href="images/gallery/6.jpeg" title="Gallery Tittle One">
                                    <img src="images/gallery/6thumbnail.png" alt="" />
                                </a>
                            </div>
                            <div class="thumb-small-gallery">
                                <a class="fancybox" rel="gallery1" href="images/gallery/15.jpeg" title="Gallery Tittle One">
                                    <img src="images/gallery/15thumbnail.png" alt="" />
                                </a>
                            </div>
                            <div class="thumb-small-gallery">
                                <a class="fancybox" rel="gallery1" href="images/gallery/18.jpeg" title="Gallery Tittle One">
                                    <img src="images/gallery/18thumnail.jpg" alt="" />
                                </a>
                            </div>
                            <div class="thumb-small-gallery">
                                <a class="fancybox" rel="gallery1" href="images/gallery/26.jpeg" title="Gallery Tittle One">
                                    <img src="images/gallery/26thumbnail.png" alt="" />
                                </a>
                            </div>
                            <div class="thumb-small-gallery">
                                <a class="fancybox" rel="gallery1" href="images/gallery/67.jpeg" title="Gallery Tittle One">
                                    <img src="images/gallery/67thumbnail.jpg" alt="" />
                                </a>
                            </div>
                            <div class="thumb-small-gallery">
                                <a class="fancybox" rel="gallery1" href="images/gallery/50.jpeg" title="Gallery Tittle One">
                                    <img src="images/gallery/50thumbnail.png" alt="" />
                                </a>
                            </div>
                            <div class="thumb-small-gallery">
                                <a class="fancybox" rel="gallery1" href="images/gallery/63.jpeg" title="Gallery Tittle One">
                                    <img src="images/gallery/63thumbnail.jpg" alt="" />
                                </a>
                            </div>
                        </div> <!-- /.galler-small-thumbs -->
                    </div> <!-- /.widget-inner -->
                </div> <!-- /.widget-main -->

            </div>
        </div>
    </div>



<?php include 'footer.php'; ?>
